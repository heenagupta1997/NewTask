export const environment = {
  production: true,
  apiURL: "https://dummy.restapiexample.com/api/v1/employees"
};
