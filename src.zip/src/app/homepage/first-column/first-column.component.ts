import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first-column',
  templateUrl: './first-column.component.html',
  styleUrls: ['./first-column.component.css']
})
export class FirstColumnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  previous() {

  }

  next() {
    
  }

}
